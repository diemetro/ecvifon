#/bin/bash

export FLASK_APP=app
export FLASK_ENV=development

python3 -m flask run